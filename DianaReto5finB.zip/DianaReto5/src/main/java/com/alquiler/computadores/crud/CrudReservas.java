package com.alquiler.computadores.crud;
import java.util.Date;
import java.util.List;
import com.alquiler.computadores.modelo.Reservaciones;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CrudReservas extends CrudRepository<Reservaciones,Integer>  {

    @Query("Select reservas.client, COUNT(reservas.client) from Reservaciones as reservas group by reservas.client order by COUNT(reservas.client) DESC")
    public List<Object[]> cantReservacionesByClient();
    
    public List<Reservaciones> findByStartDateAfterAndStartDateBefore(Date fechaIni,Date fechaFin);
    
    public List<Reservaciones> findAllByStatus(String estado);
    
}
