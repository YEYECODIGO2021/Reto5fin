package com.alquiler.computadores.crud;

import com.alquiler.computadores.modelo.Categoria;

import org.springframework.data.repository.CrudRepository;

public interface CrudCategoria extends CrudRepository<Categoria,Integer> {
    
}
