package com.alquiler.computadores.crud;

import com.alquiler.computadores.modelo.Computador;

import org.springframework.data.repository.CrudRepository;

public interface CrudComputadores extends CrudRepository<Computador,Integer>{
    
}
