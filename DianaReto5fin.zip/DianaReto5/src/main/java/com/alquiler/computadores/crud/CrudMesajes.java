package com.alquiler.computadores.crud;

import com.alquiler.computadores.modelo.Mensaje;

import org.springframework.data.repository.CrudRepository;

public interface CrudMesajes extends CrudRepository<Mensaje,Integer> {
    
}
