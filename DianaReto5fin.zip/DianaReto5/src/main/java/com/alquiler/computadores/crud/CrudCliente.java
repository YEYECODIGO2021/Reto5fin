package com.alquiler.computadores.crud;

import com.alquiler.computadores.modelo.Cliente;

import org.springframework.data.repository.CrudRepository;

public interface CrudCliente extends CrudRepository<Cliente,Integer>{
    
}
