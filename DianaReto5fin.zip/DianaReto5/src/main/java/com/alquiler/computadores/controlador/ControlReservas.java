package com.alquiler.computadores.controlador;

import java.util.List;
import java.util.Optional;

import com.alquiler.computadores.modelo.ContarClientes;
import com.alquiler.computadores.modelo.EstadoReservas;
import com.alquiler.computadores.modelo.Reservaciones;
import com.alquiler.computadores.servicio.ServiReservas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/Reservation")
@CrossOrigin(origins = "*",methods = {RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT,RequestMethod.GET})
public class ControlReservas {

    @Autowired
    private ServiReservas serviReservas;

    @GetMapping("/all")
    public List<Reservaciones> getReservas(){
        return serviReservas.getReservas();
    }
    
    @GetMapping("/{id}")
    public Optional<Reservaciones>getReserva(@PathVariable("id") int idReserva){
        return serviReservas.getIdReserva(idReserva);
    }

    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Reservaciones saveReserva(@RequestBody Reservaciones reservas){
        return serviReservas.guardarReserva(reservas);
    }

    @PutMapping("/update")
    @ResponseStatus(HttpStatus.CREATED)
    public Reservaciones updateReserva(@RequestBody Reservaciones reservas){
        return serviReservas.actualizarReserva(reservas);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public boolean delCategoria(@PathVariable("id") int idReserva){
        return serviReservas.eliminarReserva(idReserva);
    }

    @GetMapping("/report-status")
    public EstadoReservas getEstadoReserva(){
        return serviReservas.reporteEstadosServi();
    }

    @GetMapping("/report-dates/{dateOne}/{dateTwo}")
    public List<Reservaciones> getReservaFecha(@PathVariable("dateOne")String dateOne,@PathVariable("dateTwo")String dateTwo){
        return serviReservas.reportePorTiempo(dateOne, dateTwo);
    }

    @GetMapping("/report-clients")
    public List<ContarClientes> getClientes(){
        return serviReservas.reporteDeClientes();

    }

    
}