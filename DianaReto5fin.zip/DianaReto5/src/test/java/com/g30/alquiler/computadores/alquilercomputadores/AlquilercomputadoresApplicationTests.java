package com.g30.alquiler.computadores.alquilercomputadores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlquilercomputadoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
